<?php
$pageTitle = 'Detalles del Militante';
$content = 'militantes/details-content.php';
require_once dirname(__DIR__) . '/layout.php';
?>