<?php
// Configuración de la base de datos
define('DB_HOST', 'srv961.hstgr.io');
define('DB_USER', 'u661117467_admin');
define('DB_PASS', 'w9R#*dcNX8i');
define('DB_NAME', 'u661117467_militantes');

// Conexión a la base de datos
function getDBConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    // Verificar conexión
    if ($conn->connect_error) {
        die("Error de conexión: " . $conn->connect_error);
    }
    
    // Establecer charset
    $conn->set_charset("utf8");
    
    return $conn;
}

// Función para sanitizar inputs
function sanitizeInput($data) {
    $conn = getDBConnection();
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    $data = $conn->real_escape_string($data);
    return $data;
}
?>