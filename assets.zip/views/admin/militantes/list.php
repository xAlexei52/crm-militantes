<?php
$pageTitle = 'Militantes';
$content = 'militantes/list-content.php';
require_once dirname(__DIR__) . '/layout.php';
?>