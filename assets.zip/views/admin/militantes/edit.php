<?php
$pageTitle = 'Editar Militante';
$content = 'militantes/edit-content.php';
require_once dirname(__DIR__) . '/layout.php';
?>