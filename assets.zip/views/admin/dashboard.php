<?php
$pageTitle = 'Dashboard';
$content = 'dashboard-content.php';
require_once __DIR__ . '/layout.php';
?>